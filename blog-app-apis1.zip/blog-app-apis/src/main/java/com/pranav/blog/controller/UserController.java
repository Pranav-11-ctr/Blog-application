package com.pranav.blog.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.pranav.blog.payloads.ApiResponse;
import com.pranav.blog.payloads.UserDto;
import com.pranav.blog.services.UserService;

@RestController
@RequestMapping("/api/users")
public class UserController {
	
	@Autowired
	private UserService userService;
	
	//Post-create -user
	@PostMapping("/")
	public ResponseEntity<UserDto> createUser(@Valid @RequestBody UserDto user)
	{
		UserDto userDto = this.userService.createUser(user);
		return new ResponseEntity<>(userDto,HttpStatus.CREATED);
	}
	//Put-delete-user
	//@Pathvariable("userId") int uid is also correct here
	@PutMapping("/{userId}")
	public ResponseEntity<UserDto> updateUser(@Valid@RequestBody UserDto user,@PathVariable int userId)
	{
		UserDto userDto = this.userService.updateUser(user, userId);
		return new ResponseEntity<>(userDto,HttpStatus.OK);
	}
	
	//delete-user
	@DeleteMapping("/{userId}")
	public ResponseEntity<ApiResponse> deleteUser(@PathVariable int userId)
	{
		this.userService.deleteUser(userId);
		return new ResponseEntity<>(new ApiResponse("User deleted successfully",true),HttpStatus.OK);
	}
	//Get One User
	@GetMapping("/{userId}")
	public ResponseEntity<UserDto> getOneUser(@PathVariable int userId)
	{
		UserDto userDto = this.userService.getUserById(userId);
		return new ResponseEntity<>(userDto,HttpStatus.OK);
	}
	
	//Get all User
	@GetMapping("/")
	public ResponseEntity<List<UserDto>> getAllUser()
	{
		List<UserDto> list = this.userService.getAllUser();
//		return new ResponseEntity<List<UserDto>>(list,HttpStatus.OK); this is also right
		return ResponseEntity.ok(list);
	}

}
