package com.pranav.blog.services.impl;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pranav.blog.entities.Category;
import com.pranav.blog.exception.ResouceNotFoundException;
import com.pranav.blog.payloads.CategoryDto;
import com.pranav.blog.repositories.CategoryRepo;
import com.pranav.blog.services.CategoryService;

@Service
public class CategoryServiceImpl implements CategoryService {

	@Autowired
	private CategoryRepo categoryRepo;
	
	@Autowired
	private ModelMapper modelMapper;
	
	@Override
	public CategoryDto createCategory(CategoryDto category) {
		Category category2 = this.modelMapper.map(category, Category.class);
		Category category3 = this.categoryRepo.save(category2);
		return this.modelMapper.map(category3, CategoryDto.class);
	}

	@Override
	public CategoryDto updateCategory(CategoryDto category, int categoryId) {
	 Category category1= this.categoryRepo.findById(categoryId).orElseThrow(()->new ResouceNotFoundException("Category","CategoryId",categoryId));
	 category1.setCategoryDescription(category.getCategoryDescription());
	 category1.setCategoryTitle(category.getCategoryTitle());
	 Category category2 = this.categoryRepo.save(category1);
		return this.modelMapper.map(category2, CategoryDto.class);
	}

	@Override
	public CategoryDto getCategory(int categoryId) {
		 Category category1= this.categoryRepo.findById(categoryId).orElseThrow(()->new ResouceNotFoundException("Category","CategoryId",categoryId));
		return this.modelMapper.map(category1, CategoryDto.class);
	}

	@Override
	public List<CategoryDto> getAllCategory() {
		List<Category> list = this.categoryRepo.findAll();
	    List<CategoryDto> list2 = list.stream().map((category)->this.modelMapper.map(category, CategoryDto.class)).collect(Collectors.toList());
	    
		return list2;
	}

	@Override
	public void deleteCategory(int categoryId) {
		Category category=this.categoryRepo.findById(categoryId).orElseThrow(()->new ResouceNotFoundException("Category","CategoryId",categoryId));
		this.categoryRepo.delete(category);

	}

}
