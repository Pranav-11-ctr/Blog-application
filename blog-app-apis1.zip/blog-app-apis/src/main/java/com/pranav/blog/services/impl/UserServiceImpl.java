package com.pranav.blog.services.impl;

import java.util.List;

import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pranav.blog.entities.User;
import com.pranav.blog.exception.ResouceNotFoundException;
import com.pranav.blog.payloads.UserDto;
import com.pranav.blog.repositories.UserRepo;
import com.pranav.blog.services.UserService;

@Service
public class UserServiceImpl implements UserService{

	@Autowired
	private UserRepo userRepo;
	
	@Autowired
	private ModelMapper modelMapper;
	
	@Override
	public UserDto createUser(UserDto user) {
		
		User user1=this.dtoToUser(user);
		User user2 = this.userRepo.save(user1);
		UserDto userToDto = this.userToDto(user2);

		
		return userToDto;
	}

	@Override
	public UserDto updateUser(UserDto user, int userId) {
		User user1=this.userRepo.findById(userId).orElseThrow(()->new ResouceNotFoundException("User"," id",userId));
		user1.setName(user.getName());
		user1.setEmail(user.getEmail());
		user1.setPassword(user.getPassword());
		user1.setAbout(user.getAbout());
		User user2 = this.userRepo.save(user1);
		return this.userToDto(user2);
	}

	@Override
	public UserDto getUserById(int userId) {
		User user = this.userRepo.findById(userId).orElseThrow(()->new ResouceNotFoundException("User"," id",userId));
		return this.userToDto(user);
	}

	@Override
	public List<UserDto> getAllUser() {
		List<User> list = this.userRepo.findAll();
		List<UserDto> list2 = list.stream().map((user)->this.userToDto(user)).collect(Collectors.toList());
		return list2;
	}

	@Override
	public void deleteUser(int userId) {
		User user=this.userRepo.findById(userId).orElseThrow(()->new ResouceNotFoundException("User"," id",userId));
		this.userRepo.delete(user);
		
	}
	
	public  User dtoToUser(UserDto userDto)
	{
		User user=this.modelMapper.map(userDto, User.class);
		
//		User user=new User();
//		user.setId(userDto.getId());
//		user.setName(userDto.getName());
//		user.setEmail(userDto.getEmail());
//		user.setPassword(userDto.getPassword());
//		user.setAbout(userDto.getAbout());
		return user;
	}
	
	public  UserDto userToDto(User user)
	{
		UserDto userDto=this.modelMapper.map(user, UserDto.class);
		
//		UserDto userDto =new UserDto();
//		userDto.setId(user.getId());
//		userDto.setName(user.getName());
//		userDto.setEmail(user.getEmail());
//		userDto.setPassword(user.getPassword());
//		userDto.setAbout(user.getAbout());
		return userDto;
	}

}
