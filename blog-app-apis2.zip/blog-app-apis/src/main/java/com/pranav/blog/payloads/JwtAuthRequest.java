package com.pranav.blog.payloads;

import lombok.Data;

@Data
public class JwtAuthRequest {
	
	//it is like email
	private String username;
	private String password;

}
