package com.pranav.blog.services;

import java.util.List;

import com.pranav.blog.payloads.CategoryDto;

public interface CategoryService {
	
	public CategoryDto createCategory(CategoryDto category);
	
	public CategoryDto updateCategory(CategoryDto category,int categoryId);
	
	public CategoryDto getCategory(int categoryId);
	
	public List<CategoryDto> getAllCategory();
	
	public void deleteCategory(int categoryId);
	

}
