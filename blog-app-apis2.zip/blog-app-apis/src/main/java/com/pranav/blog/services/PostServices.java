package com.pranav.blog.services;

import java.util.List;

import com.pranav.blog.entities.Post;
import com.pranav.blog.payloads.PostDto;
import com.pranav.blog.payloads.PostResponse;

public interface PostServices {
	
	
	PostDto createPost(PostDto postDto,int user_id,int category_id);
	PostDto updatePost(PostDto postDto,int post_id);
	void deletePost(int post_id);
	PostDto getSinglePost(int post_id);
	PostResponse getAllPosts(int pageNumber,int pageSize,String sortBy,String sortDir);
	
	//Get all Posts By Category
	List<PostDto> getPostByCategory(int categoryId);
	
	//Get all Posts by user
	List<PostDto> getPostByUser(int userId);
	
	//Search posts By keywords
	List<PostDto> searchPost(String keyWords);
	
}
