package com.pranav.blog.services.impl;

import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.pranav.blog.entities.Category;
import com.pranav.blog.entities.Post;
import com.pranav.blog.entities.User;
import com.pranav.blog.exception.ResouceNotFoundException;
import com.pranav.blog.payloads.PostDto;
import com.pranav.blog.payloads.PostResponse;
import com.pranav.blog.repositories.CategoryRepo;
import com.pranav.blog.repositories.PostRepo;
import com.pranav.blog.repositories.UserRepo;
import com.pranav.blog.services.PostServices;

@Service
public class PostServiceImpl implements PostServices {

	
	@Autowired
	private PostRepo postRepo;
	
	@Autowired
	private ModelMapper modelMapper;
	
	@Autowired
	private UserRepo userRepo;
	
	@Autowired
	private CategoryRepo categoryRepo;
	
	@Override
	public PostDto createPost(PostDto postDto,int userId,int category_id) {
		
		User user=this.userRepo.findById(userId).orElseThrow(()->new ResouceNotFoundException("User", "UserId", userId));
		Category category=this.categoryRepo.findById(category_id).orElseThrow(()->new ResouceNotFoundException("Category","Category_id", category_id));
		Post post = this.modelMapper.map(postDto, Post.class);
		post.setImageName("default.png");
		post.setAddedDate(new Date());
		post.setUser(user);
		post.setCategory(category);
		
		Post post2 = this.postRepo.save(post);
		
		return this.modelMapper.map(post2, PostDto.class);
	}

	@Override
	public PostDto updatePost(PostDto postDto, int post_id) {
		Post post = this.postRepo.findById(post_id).orElseThrow(()->new ResouceNotFoundException("Post", "PostId", post_id));
		post.setTitle(postDto.getTitle());
		post.setContent(postDto.getContent());
		post.setImageName(postDto.getImageName());
		Post post2 = this.postRepo.save(post);
		return this.modelMapper.map(post2, PostDto.class);
	}

	@Override
	public void deletePost(int post_id) {
		Post post = this.postRepo.findById(post_id).orElseThrow(()->new ResouceNotFoundException("Post", "PostId", post_id));
		this.postRepo.delete(post);

	}

	@Override
	public PostDto getSinglePost(int post_id) {
		Post post = this.postRepo.findById(post_id).orElseThrow(()->new ResouceNotFoundException("Post", "PostId", post_id));
		
		return this.modelMapper.map(post, PostDto.class);
	}

	@Override
	public PostResponse getAllPosts(int pageNumber,int pageSize,String sortBy,String sortDir) {
		//By ternary operator
	//	Sort sort=sortDir.equalsIgnoreCase("asc")?Sort.by(sortBy).ascending():Sort.by(sortBy).descending();
		
		Sort sort=null;
		if(sortDir.equalsIgnoreCase("asc"))
			sort=Sort.by(sortBy).ascending();
		else
			sort=Sort.by(sortBy).descending();
		
		Pageable p=PageRequest.of(pageNumber, pageSize, sort);
		Page<Post> page = this.postRepo.findAll(p);
		List<Post> list = page.getContent();
		//List<Post> list = this.postRepo.findAll();
		List<PostDto> list1=list.stream().map((post)->this.modelMapper.map(post,PostDto.class)).collect(Collectors.toList());
		
		PostResponse postResponse=new PostResponse();
		postResponse.setContent(list1);
		postResponse.setPageNumber(page.getNumber());
		postResponse.setPageSize(page.getSize());
		postResponse.setTotalElements(page.getTotalElements());
		postResponse.setTotalPages(page.getTotalPages());
		postResponse.setLastPage(page.isLast());
		
		return postResponse;
	}

	@Override
	public List<PostDto> getPostByCategory(int categoryId) {
		Category category = this.categoryRepo.findById(categoryId).orElseThrow(()->new ResouceNotFoundException("Category","Category_id", categoryId));
		List<Post> list = this.postRepo.findByCategory(category);
		List<PostDto> list1= list.stream().map((post)->this.modelMapper.map(post, PostDto.class)).collect(Collectors.toList());
		return list1;
	}

	@Override
	public List<PostDto> getPostByUser(int userId) {
		User user = this.userRepo.findById(userId).orElseThrow(()->new ResouceNotFoundException("User","User_id", userId));
		List<Post> list = this.postRepo.findByUser(user);
		List<PostDto> list1= list.stream().map((post)->this.modelMapper.map(post, PostDto.class)).collect(Collectors.toList());
		return list1;
	}

	@Override
	public List<PostDto> searchPost(String keyWords) {
		List<Post> titleContaining = this.postRepo.findByTitleContaining(keyWords);
		List<PostDto> list = titleContaining.stream().map((title)->this.modelMapper.map(title, PostDto.class)).collect(Collectors.toList());
		
		return list;
	}

}
